package OracleDBQueueTest.model;

public class SUB_ADR_LIST {
	private T_SUB_ADR T_SUB_ADR;

	public T_SUB_ADR getT_SUB_ADR() {
		return T_SUB_ADR;
	}

	public void setT_SUB_ADR(T_SUB_ADR T_SUB_ADR) {
		this.T_SUB_ADR = T_SUB_ADR;
	}

	@Override
	public String toString() {
		return "ClassPojo [T_SUB_ADR = " + T_SUB_ADR + "]";
	}
}
