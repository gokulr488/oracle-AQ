package OracleDBQueueTest.model;
public class T_SUB_CLL
{
    private String CLL_NOTIFICATION_METHOD;

    private String CLL_THRESHOLD_1;

    private String CLL_THRESHOLD_3;

    private String CLL_VALUE;

    private String CLL_THRESHOLD_2;

    private String CLL_ACTIVATION_DATE;

    private String CLL_START_DATE;

    private String CLL_TYPE;

    private String CLL_END_DATE;

    private String CLL_NOTIFICATION_NUMBER;

    public String getCLL_NOTIFICATION_METHOD ()
    {
        return CLL_NOTIFICATION_METHOD;
    }

    public void setCLL_NOTIFICATION_METHOD (String CLL_NOTIFICATION_METHOD)
    {
        this.CLL_NOTIFICATION_METHOD = CLL_NOTIFICATION_METHOD;
    }

    public String getCLL_THRESHOLD_1 ()
    {
        return CLL_THRESHOLD_1;
    }

    public void setCLL_THRESHOLD_1 (String CLL_THRESHOLD_1)
    {
        this.CLL_THRESHOLD_1 = CLL_THRESHOLD_1;
    }

    public String getCLL_THRESHOLD_3 ()
    {
        return CLL_THRESHOLD_3;
    }

    public void setCLL_THRESHOLD_3 (String CLL_THRESHOLD_3)
    {
        this.CLL_THRESHOLD_3 = CLL_THRESHOLD_3;
    }

    public String getCLL_VALUE ()
    {
        return CLL_VALUE;
    }

    public void setCLL_VALUE (String CLL_VALUE)
    {
        this.CLL_VALUE = CLL_VALUE;
    }

    public String getCLL_THRESHOLD_2 ()
    {
        return CLL_THRESHOLD_2;
    }

    public void setCLL_THRESHOLD_2 (String CLL_THRESHOLD_2)
    {
        this.CLL_THRESHOLD_2 = CLL_THRESHOLD_2;
    }

    public String getCLL_ACTIVATION_DATE ()
    {
        return CLL_ACTIVATION_DATE;
    }

    public void setCLL_ACTIVATION_DATE (String CLL_ACTIVATION_DATE)
    {
        this.CLL_ACTIVATION_DATE = CLL_ACTIVATION_DATE;
    }

    public String getCLL_START_DATE ()
    {
        return CLL_START_DATE;
    }

    public void setCLL_START_DATE (String CLL_START_DATE)
    {
        this.CLL_START_DATE = CLL_START_DATE;
    }

    public String getCLL_TYPE ()
    {
        return CLL_TYPE;
    }

    public void setCLL_TYPE (String CLL_TYPE)
    {
        this.CLL_TYPE = CLL_TYPE;
    }

    public String getCLL_END_DATE ()
    {
        return CLL_END_DATE;
    }

    public void setCLL_END_DATE (String CLL_END_DATE)
    {
        this.CLL_END_DATE = CLL_END_DATE;
    }

    public String getCLL_NOTIFICATION_NUMBER ()
    {
        return CLL_NOTIFICATION_NUMBER;
    }

    public void setCLL_NOTIFICATION_NUMBER (String CLL_NOTIFICATION_NUMBER)
    {
        this.CLL_NOTIFICATION_NUMBER = CLL_NOTIFICATION_NUMBER;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [CLL_NOTIFICATION_METHOD = "+CLL_NOTIFICATION_METHOD+", CLL_THRESHOLD_1 = "+CLL_THRESHOLD_1+", CLL_THRESHOLD_3 = "+CLL_THRESHOLD_3+", CLL_VALUE = "+CLL_VALUE+", CLL_THRESHOLD_2 = "+CLL_THRESHOLD_2+", CLL_ACTIVATION_DATE = "+CLL_ACTIVATION_DATE+", CLL_START_DATE = "+CLL_START_DATE+", CLL_TYPE = "+CLL_TYPE+", CLL_END_DATE = "+CLL_END_DATE+", CLL_NOTIFICATION_NUMBER = "+CLL_NOTIFICATION_NUMBER+"]";
    }
}