package OracleDBQueueTest.model;


public class SUB_ID_LIST
{
private T_SUB_ID T_SUB_ID;

public T_SUB_ID getT_SUB_ID ()
{
return T_SUB_ID;
}

public void setT_SUB_ID (T_SUB_ID T_SUB_ID)
{
this.T_SUB_ID = T_SUB_ID;
}

@Override
public String toString()
{
return "ClassPojo [T_SUB_ID = "+T_SUB_ID+"]";
}
}

