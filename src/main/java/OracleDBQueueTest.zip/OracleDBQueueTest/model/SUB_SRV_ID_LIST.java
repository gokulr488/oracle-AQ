package OracleDBQueueTest.model;
public class SUB_SRV_ID_LIST
{
    private T_SRV_ID T_SRV_ID;

    public T_SRV_ID getT_SRV_ID ()
    {
        return T_SRV_ID;
    }

    public void setT_SRV_ID (T_SRV_ID T_SRV_ID)
    {
        this.T_SRV_ID = T_SRV_ID;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [T_SRV_ID = "+T_SRV_ID+"]";
    }
}
			
