package OracleDBQueueTest.model;


public class SUB_SRV_ATR_LIST
{
private T_SRV_ATR T_SRV_ATR;

public T_SRV_ATR getT_SRV_ATR ()
{
return T_SRV_ATR;
}

public void setT_SRV_ATR (T_SRV_ATR T_SRV_ATR)
{
this.T_SRV_ATR = T_SRV_ATR;
}

@Override
public String toString()
{
return "ClassPojo [T_SRV_ATR = "+T_SRV_ATR+"]";
}
}

