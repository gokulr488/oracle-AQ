package OracleDBQueueTest.model;

public class SUB_SRV_LIST {
	private T_SUB_SRV T_SUB_SRV;

	public T_SUB_SRV getT_SUB_SRV() {
		return T_SUB_SRV;
	}

	public void setT_SUB_SRV(T_SUB_SRV T_SUB_SRV) {
		this.T_SUB_SRV = T_SUB_SRV;
	}

	@Override
	public String toString() {
		return "ClassPojo [T_SUB_SRV = " + T_SUB_SRV + "]";
	}
}