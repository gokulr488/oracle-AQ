package OracleDBQueueTest.model;

public class SUB_CLL_LIST
{
    private T_SUB_CLL T_SUB_CLL;

    public T_SUB_CLL getT_SUB_CLL ()
    {
        return T_SUB_CLL;
    }

    public void setT_SUB_CLL (T_SUB_CLL T_SUB_CLL)
    {
        this.T_SUB_CLL = T_SUB_CLL;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [T_SUB_CLL = "+T_SUB_CLL+"]";
    }
}
			
	