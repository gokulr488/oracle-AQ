package OracleDBQueueTest.model;


public class SUB_DTL_LIST
{
private T_SUB_DTL T_SUB_DTL;

public T_SUB_DTL getT_SUB_DTL ()
{
return T_SUB_DTL;
}

public void setT_SUB_DTL (T_SUB_DTL T_SUB_DTL)
{
this.T_SUB_DTL = T_SUB_DTL;
}

@Override
public String toString()
{
return "ClassPojo [T_SUB_DTL = "+T_SUB_DTL+"]";
}
}
