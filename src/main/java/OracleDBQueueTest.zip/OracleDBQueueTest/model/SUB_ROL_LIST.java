package OracleDBQueueTest.model;

public class SUB_ROL_LIST
{
    private T_SUB_ROL T_SUB_ROL;

    public T_SUB_ROL getT_SUB_ROL ()
    {
        return T_SUB_ROL;
    }

    public void setT_SUB_ROL (T_SUB_ROL T_SUB_ROL)
    {
        this.T_SUB_ROL = T_SUB_ROL;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [T_SUB_ROL = "+T_SUB_ROL+"]";
    }
}
			
			