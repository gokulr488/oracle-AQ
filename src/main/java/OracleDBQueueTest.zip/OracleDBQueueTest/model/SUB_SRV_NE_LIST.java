package OracleDBQueueTest.model;

public class SUB_SRV_NE_LIST
{
    private T_SRV_NE T_SRV_NE;

    public T_SRV_NE getT_SRV_NE ()
    {
        return T_SRV_NE;
    }

    public void setT_SRV_NE (T_SRV_NE T_SRV_NE)
    {
        this.T_SRV_NE = T_SRV_NE;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [T_SRV_NE = "+T_SRV_NE+"]";
    }
}
			
		